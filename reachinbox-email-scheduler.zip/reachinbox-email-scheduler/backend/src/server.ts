
import express, { Request, Response } from "express";

const app = express();

const PORT = 5000;

// Middleware to read JSON data
app.use(express.json());

// Test API
app.get("/", (req: Request, res: Response) => {
    res.send("ReachInbox Email Scheduler Backend is Running!");
});

// Health check API
app.get("/health", (req: Request, res: Response) => {
    res.status(200).json({
        success: true,
        message: "Backend is healthy",
        timestamp: new Date()
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
