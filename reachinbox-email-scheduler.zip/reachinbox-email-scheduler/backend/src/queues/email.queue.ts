
import { Queue } from "bullmq";
import redisConnection from "../config/redis.js";

export const emailQueue = new Queue("email-queue", {
    connection: redisConnection,
    defaultJobOptions: {
        attempts: 3,
        backoff: {
            type: "exponential",
            delay: 2000
        },
        removeOnComplete: false,
        removeOnFail: false
    }
});

export async function scheduleEmail(
    emailId: string,
    scheduledAt: Date
) {
    const delay = Math.max(
        0,
        scheduledAt.getTime() - Date.now()
    );

    const job = await emailQueue.add(
        "send-email",
        { emailId },
        {
            jobId: emailId,
            delay
        }
    );

    return job;
}
