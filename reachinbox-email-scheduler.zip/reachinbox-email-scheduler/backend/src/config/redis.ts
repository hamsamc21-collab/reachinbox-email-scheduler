
import "dotenv/config";
import IORedis from "ioredis";

const redisConnection = new IORedis({
    host: process.env.REDIS_HOST || "127.0.0.1",
    port: Number(process.env.REDIS_PORT || 6379),
    maxRetriesPerRequest: null
});

redisConnection.on("connect", () => {
    console.log("Redis connected successfully!");
});

redisConnection.on("error", (error) => {
    console.error("Redis connection error:", error);
});

export default redisConnection;
