
import redisConnection from "./config/redis.js";

async function testRedis() {
    try {
        const response = await redisConnection.ping();

        console.log("Redis response:", response);

        if (response === "PONG") {
            console.log("Redis connected successfully!");
        }

    } catch (error) {
        console.error("Redis test failed:", error);

    } finally {
        await redisConnection.quit();
    }
}

testRedis();
