
import "dotenv/config";
import nodemailer from "nodemailer";

async function testEmail() {
    console.log("SMTP HOST:", process.env.SMTP_HOST);
    console.log("SMTP PORT:", process.env.SMTP_PORT);
    console.log("SMTP USER:", process.env.SMTP_USER);
    console.log("PASSWORD EXISTS:", Boolean(process.env.SMTP_PASS));
    console.log("PASSWORD LENGTH:", process.env.SMTP_PASS?.length);

    const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT),
        secure: false,
        requireTLS: true,
        auth: {
            user: process.env.SMTP_USER?.trim(),
            pass: process.env.SMTP_PASS?.trim()
        }
    });

    try {
        await transporter.verify();
        console.log("SMTP authentication successful!");

        const info = await transporter.sendMail({
            from: process.env.SMTP_USER,
            to: "test@example.com",
            subject: "ReachInbox Test",
            text: "First successful ReachInbox test email!"
        });

        console.log("Email sent successfully!");
        console.log(
            "Preview:",
            nodemailer.getTestMessageUrl(info)
        );

    } catch (error) {
        console.error("SMTP test failed:", error);
    } finally {
        await transporter.close();
    }
}

testEmail();
