import "dotenv/config";
import { Worker, Job } from "bullmq";
import redisConnection from "../config/redis.js";
import prisma from "../config/database.js";
import { sendEmail } from "../integrations/email/email.service.js";

const CONCURRENCY = Number(process.env.WORKER_CONCURRENCY || 2);

const emailWorker = new Worker(
    "email-queue",
    async (job: Job) => {
        const { emailId } = job.data;

        console.log("Processing email:", emailId);

        const email = await prisma.email.findUnique({
            where: { id: emailId },
            include: {
                campaign: {
                    include: {
                        sender: true
                    }
                }
            }
        });

        if (!email) {
            throw new Error("Email not found: " + emailId);
        }

        // Prevent duplicate sending
        if (email.status === "SENT") {
            return { message: "Already sent" };
        }

        await prisma.email.update({
            where: { id: emailId },
            data: { status: "PROCESSING" }
        });

        try {
            const result = await sendEmail({
                to: email.recipient,
                subject: email.subject,
                body: email.body
            });

            await prisma.email.update({
                where: { id: emailId },
                data: {
                    status: "SENT",
                    sentAt: new Date()
                }
            });

            return {
                message: "Email sent",
                messageId: result.messageId
            };

        } catch (error) {
            await prisma.email.update({
                where: { id: emailId },
                data: {
                    status: "FAILED",
                    errorMessage:
                        error instanceof Error
                            ? error.message
                            : "Unknown email error"
                }
            });

            throw error;
        }
    },
    {
        connection: redisConnection,
        concurrency: CONCURRENCY
    }
);

emailWorker.on("completed", (job) => {
    console.log("Email job completed:", job.id);
});

emailWorker.on("failed", (job, error) => {
    console.error("Email job failed:", job?.id, error.message);
});

emailWorker.on("error", (error) => {
    console.error("Worker error:", error);
});

console.log(`Email worker started. Concurrency: ${CONCURRENCY}`);

export default emailWorker;
