
import {
    sendEmail,
    verifyEmailConnection
} from "./integrations/email/email.service.js";

async function testEmail() {
    try {
        await verifyEmailConnection();

        const result = await sendEmail({
            to: "test@example.com",
            subject: "ReachInbox SMTP Test",
            body: "Hello! This is our first test email from ReachInbox."
        });

        console.log("Preview your email here:");
        console.log(result.previewUrl);

    } catch (error) {
        console.error("Email test failed:", error);

    }
}

testEmail();
